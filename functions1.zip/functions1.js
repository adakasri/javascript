//functins scope
number=9985565589
function mybronumber(number1)
{
    var myphonenumber=function()
    {
        let number=9182205557;
        console.log('my number',number);
        return number;
    }
    let numb=number;
    console.log('my bro number',number);
    return numb;
}console.log(mybronumber());


//
/*function myphonenumber(number1)
    {
        let number=number1;
        console.log('my number');
        return number;
    }
    console.log(myphonenumber(9182201557));