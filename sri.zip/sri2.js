let manu= 1425;
manu=535446348;
console.log(manu);

//constant
const sri1=12358;
sri1=235345;
console.log(sri1);

// use var keyword
console.log(sri2);
var sri2=1234;
