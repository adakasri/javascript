let sri=true;
console.log(sri);

let sri1=true;
console.log(typeof sri1);

//
let sri2=true;
sri2=!sri2;
console.log(typeof sri2);

let sri3=true;
sri3=!sri3;
console.log(sri3);
