//(typeof) string or number
let sri=123;
console.log(typeof sri);

let sri1='123';
console.log(typeof sri1);