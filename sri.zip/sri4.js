let sri=25;
sri=sri+5;//use +,-,*,'/',%..
console.log(sri);

//another way 
let sri1=8;
sri1 +=2;// -=,*=,/=,%=.. 
console.log(sri1);

let sri2=123;
console.log(++sri2);//--befor the variable
