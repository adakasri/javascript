let sri=1+4*2;//(),/*,+-
console.log(sri);


//number precision
let sri2=1.2+1.4;
console.log(sri2);

//   -ve numbers
let sri3=2- -22;
console.log(--sri3);