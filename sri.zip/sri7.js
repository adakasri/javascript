//srings
let sri="sriman";
sri=sri +     'narayana';
console.log(sri);

//string(changing to lowercase,uppercase)
let sri1="sriman";
sri1=sri1.toUpperCase();
console.log(sri1);

let sri2="Sriman";
sri2=sri2.toLowerCase();
console.log(sri2);

//substring
let sr="sriman";
sr=sr.substring(1);
console.log(sr);

//
let sri0="sriman";
sri0=sri0.length;
console.log(sri0);

//
let sri01='123';
console.log(typeof sri01);

//
let sri011='srima';
console.log(sri011+'n');
