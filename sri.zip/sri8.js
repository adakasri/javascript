//converting number and string
let sri=23;
sri=sri.toString();
console.log(typeof sri);

//converting string and number
let sri1=Number.parseFloat('1234');
console.log(sri1);

let sri2=Number.parseInt('1234');
console.log(typeof sri2);