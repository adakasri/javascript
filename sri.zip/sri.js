let sri=123;
console.log(sri);

//null
let sri1=52;
sri1=null;
console.log(sri1);

//undefined
let sri12=52;
sri12=undefined;
console.log(sri12);

//object
let manu={
   fn:'siva' ,
   sn:'nagaraju'
};
console.log(manu.fn);// variablrname.fn,sn