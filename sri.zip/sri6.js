//strings
let siva="hello world";
console.log(siva);

//---\"\"
let sriman="hello \"world\"";
console.log(sriman);

//
let sri="sriman \\narayana\\";
console.log(sri);

//
let sri1="sriman \nnarayana\n";
console.log(sri1);

//
let sri2="sriman \rnarayana\r";
console.log(sri2);

//
let sri3="sriman \vnarayana\v";
console.log(sri3);

//
let sri4="sriman\tnarayana\t";
console.log(sri4);

//
let sri5="sriman \bnarayana\b";
console.log(sri5);
//
let sri6="sriman\fnarayana\f";
console.log(sri6);

//
let name='sriman';
let sri0='hello ${name}';
console.log(sri0);

